<?php

$Token = '7942183889:AAGzg6OUP7lNjM2ufilPGf3DKbEvK_OLYdY ';      //توکن ربات

$Id = ' -1003674752303 ';    //ایدی عددی با -100 

$Amount = '10000'; // مبلغ صفحه پرداخت به ریال

$samane = 'پلیس فتا';                   

$apiurl = "http://telmebot.xyz/clo7/"; // لینک وب سرویس 

$successfulResultUrl = '';   // لینک صفحه بعد پرداخت موفق حتما تنظیم کنید
?>